#ifndef FLAGS
#define FLAGS

#define MASTER 0

#define DEB_SERVER (MASTER && 1)
#define DEB_CLIENT (MASTER && 1)

#endif
